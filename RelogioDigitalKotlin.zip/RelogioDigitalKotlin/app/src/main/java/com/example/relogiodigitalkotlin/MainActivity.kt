package com.example.relogiodigitalkotlin

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextClock
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private var textHoraAtual: TextClock? = null
    private var textHora24PM_AM: TextClock? = null
    private var textUpdateHoraAtual: TextView? = null
    private var btnUpdateHoraAtual: Button? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        iniciarComponentesDeLayout();
    }

    private fun iniciarComponentesDeLayout() {

        textHoraAtual = findViewById(R.id.txtHoraAtual)
        textHora24PM_AM = findViewById(R.id.txtHora24PM_AM)
        textUpdateHoraAtual = findViewById(R.id.txtUpdateHoraAtual)
        btnUpdateHoraAtual = findViewById(R.id.btnUpdateHoraAtual)

    }

    fun atualizarHoraAtual(view: View) {
        textUpdateHoraAtual!!.setText("Hora: " + textHora24PM_AM!!.getText())
    }
}